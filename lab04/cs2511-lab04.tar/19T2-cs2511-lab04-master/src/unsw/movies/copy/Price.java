package unsw.movies.copy;

public interface Price {
    public double getCharge(int daysRented);
}
