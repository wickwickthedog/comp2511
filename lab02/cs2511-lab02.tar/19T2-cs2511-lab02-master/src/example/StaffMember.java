package example;

/**
 * A staff member
 * @author Robert Clifton-Everest
 *
 */
public class StaffMember {

}
