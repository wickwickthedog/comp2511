/**
 *
 */
package unsw.automata.copy;

/**
 * Conway's Game of Life on a 10x10 grid.
 *
 * @author Robert Clifton-Everest
 *
 */
public class GameOfLife {

    public GameOfLife() {
        // TODO At the start all cells are dead
    }

    public void ensureAlive(int x, int y) {
        // TODO Set the cell at (x,y) as alive
    }

    public void ensureDead(int x, int y) {
        // TODO Set the cell at (x,y) as dead
    }

    public boolean isAlive(int x, int y) {
        // TODO Return true if the cell is alive
        return false;
    }

    public void tick() {
        // TODO Transition the game to the next generation.
    }

}
