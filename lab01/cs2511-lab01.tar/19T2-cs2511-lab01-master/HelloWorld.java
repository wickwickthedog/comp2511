/**
 * A simple java program that prints a hello world message to the console
 * 
 */
class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello, Welcome to COMP2511!");
	}
}